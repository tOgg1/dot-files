Command-Not-Found
=================

Displays installation information for not found commands by loading the
[command-not-found][1] tool on Debian-based and Arch Linux-based distributions.

Authors
-------

*The authors of this module should be contacted via the [issue tracker][2].*

  - [Joseph Booker](https://github.com/sargas)

[1]: https://code.launchpad.net/command-not-found
[2]: https://github.com/sorin-ionescu/prezto/issues
